package com.rs.dao;

import java.util.ArrayList;

public class AppInsights {

	Integer uniqueViews;
	Integer shortLists;
	ArrayList<String> contactedUsers;
	
	public Integer getUniqueViews() {
		return uniqueViews;
	}
	public void setUniqueViews(Integer uniqueViews) {
		this.uniqueViews = uniqueViews;
	}
	public Integer getShortLists() {
		return shortLists;
	}
	public void setShortLists(Integer shortLists) {
		this.shortLists = shortLists;
	}
	public ArrayList<String> getContactedUsers() {
		return contactedUsers;
	}
	public void setContactedUsers(ArrayList<String> contactedUsers) {
		this.contactedUsers = contactedUsers;
	}

}
