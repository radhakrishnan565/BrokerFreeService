package com.rs.dao;

import org.bson.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ContactDetails {

	String contactNo;
	String landline_no;
	String door_no;
	String streetName;
	String area;
	String city;
	String landMark;
	String state;
	String country;
	String pincode;
	String alternateNo;
	String email;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getcontactNo() {
		return contactNo;
	}
	public void setcontactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getLandline_no() {
		return landline_no;
	}
	public void setLandline_no(String landline_no) {
		this.landline_no = landline_no;
	}
	public String getDoor_no() {
		return door_no;
	}
	public void setDoor_no(String door_no) {
		this.door_no = door_no;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLandMark() {
		return landMark;
	}
	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getAlternateNo() {
		return alternateNo;
	}
	public void setAlternateNo(String alternateNo) {
		this.alternateNo = alternateNo;
	}
	
	public Document getDocument(){
		Document document = new Document();
		document.append("contactNo", contactNo);
		document.append("landline_no",landline_no );
		document.append("door_no", door_no);
		document.append("streetName", streetName);
		document.append("area", area);
		document.append("city", city);
		document.append("landMark", landMark);
		document.append("state", state);
		document.append("country", country);
		document.append("pincode", pincode);
		document.append("alternateNo", alternateNo);
		document.append("email", email);
		return document;
	}
}
