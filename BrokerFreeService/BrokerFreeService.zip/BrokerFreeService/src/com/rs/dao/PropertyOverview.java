package com.rs.dao;

import java.util.Date;

import org.bson.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties
public class PropertyOverview {

	Integer bedrooms;
	Date postedon;
	Integer bathrooms;
	String toiletType;
	String possesion;
	Date lastUpdatedOn;
	String furnishingStatus;
	String floor;
	String description;
	String preferedtenant;
	String parking;
	String fourWheelerParking;
	String twoWheelerParking;
	String lift;	
	String propertytype;
	
	public Integer getBedrooms() {
		return bedrooms;
	}
	public void setBedrooms(Integer bedrooms) {
		this.bedrooms = bedrooms;
	}
	public Date getPostedon() {
		return postedon;
	}
	public void setPostedon(Date postedon) {
		this.postedon = postedon;
	}
	public Integer getBathrooms() {
		return bathrooms;
	}
	public void setBathrooms(Integer bathrooms) {
		this.bathrooms = bathrooms;
	}
	public String getToiletType() {
		return toiletType;
	}
	public void setToiletType(String toiletType) {
		this.toiletType = toiletType;
	}
	public String getPossesion() {
		return possesion;
	}
	public void setPossesion(String possesion) {
		this.possesion = possesion;
	}
	public Date getLastUpdatedOn() {
		return lastUpdatedOn;
	}
	public void setLastUpdatedOn(Date lastUpdatedOn) {
		this.lastUpdatedOn = lastUpdatedOn;
	}
	public String getFurnishingStatus() {
		return furnishingStatus;
	}
	public void setFurnishingStatus(String furnishingStatus) {
		this.furnishingStatus = furnishingStatus;
	}
	public String getFloor() {
		return floor;
	}
	public void setFloor(String floor) {
		this.floor = floor;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPreferedtenant() {
		return preferedtenant;
	}
	public void setPreferedtenant(String preferedtenant) {
		this.preferedtenant = preferedtenant;
	}
	public String getParking() {
		return parking;
	}
	public void setParking(String parking) {
		this.parking = parking;
	}
	public String getFourWheelerParking() {
		return fourWheelerParking;
	}
	public void setFourWheelerParking(String fourWheelerParking) {
		this.fourWheelerParking = fourWheelerParking;
	}
	public String getLift() {
		return lift;
	}
	public void setLift(String lift) {
		this.lift = lift;
	}
	public String getPropertytype() {
		return propertytype;
	}
	public void setPropertytype(String propertytype) {
		this.propertytype = propertytype;
	}
	public String getTwoWheelerParking() {
		return twoWheelerParking;
	}
	public void setTwoWheelerParking(String twoWheelerParking) {
		this.twoWheelerParking = twoWheelerParking;
	}

	public Document getDocument() {
		Document document = new Document();
		document.append("bedrooms", bedrooms);
		document.append("postedon", postedon);
		document.append("bathrooms", bathrooms);
		document.append("toiletType", toiletType);
		document.append("possesion", possesion);
		document.append("lastUpdatedOn", lastUpdatedOn);
		document.append("furnishingStatus", furnishingStatus);
		document.append("floor", floor);
		document.append("description", description);
		document.append("preferedtenant", preferedtenant);
		document.append("parking", parking);
		document.append("fourWheelerParking", fourWheelerParking);
		document.append("twoWheelerParking", twoWheelerParking);
		document.append("lift", lift);
		document.append("propertytype", propertytype);
		return document;
	}
}
