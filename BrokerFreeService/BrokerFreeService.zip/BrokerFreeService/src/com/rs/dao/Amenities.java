package com.rs.dao;

public class Amenities {
	String neighbourhood;	
	String addressdetails;
	String map;

}
