package com.rs.dao;

public class Transist {

	String	airport;
	String railway;
	String busses;

}
