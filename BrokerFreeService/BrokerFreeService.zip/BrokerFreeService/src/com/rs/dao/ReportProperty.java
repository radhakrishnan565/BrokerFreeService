package com.rs.dao;

public class ReportProperty {

	String rendtedout;
	String wronginfo;
	String broker;
	String comments;
	String stars;
	
	public String getRendtedout() {
		return rendtedout;
	}
	public void setRendtedout(String rendtedout) {
		this.rendtedout = rendtedout;
	}
	public String getWronginfo() {
		return wronginfo;
	}
	public void setWronginfo(String wronginfo) {
		this.wronginfo = wronginfo;
	}
	public String getBroker() {
		return broker;
	}
	public void setBroker(String broker) {
		this.broker = broker;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getStars() {
		return stars;
	}
	public void setStars(String stars) {
		this.stars = stars;
	}
	

}
