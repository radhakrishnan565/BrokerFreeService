package com.rs.dao;

import org.bson.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties
public class OwnerObject {

	String	ownerId;
	String name;
	String display_description;
	ContactDetails contactDetails;
	PropertyDetails propertyDetails;
	
	public PropertyDetails getPropertyDetails() {
		return propertyDetails;
	}
	public void setPropertyDetails(PropertyDetails propertyDetails) {
		this.propertyDetails = propertyDetails;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ContactDetails getContactDetails() {
		return contactDetails;
	}
	public void setContactDetails(ContactDetails contactDetails) {
		this.contactDetails = contactDetails;
	}
	public String getDisplay_description() {
		return display_description;
	}
	public void setDisplay_description(String display_description) {
		this.display_description = display_description;
	}
	public void setOwnerId(String ownerId){
		this.ownerId = ownerId;
	}
	public String getOwnerId() {
		return ownerId;
	}
	public Document getDocument(){
		
		Document document = new Document();
		document.append("ownerId", ownerId);
		document.append("name", name);
		document.append("display_description", display_description);
		
		
		if(contactDetails != null) {
			document.append("contactDetails", contactDetails.getDocument());
		}
		if(propertyDetails != null) {
			document.append("propertyDetails", propertyDetails.getDocument());
			document.append("_id", ownerId+"_"+propertyDetails.getPropertyId());
		}
		
		return document;
	}
}
