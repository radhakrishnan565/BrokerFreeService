package com.rs.server.service;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.MongoCollection;
import com.rs.dao.OwnerObject;
import com.rs.dao.util.MongoConnectionUtil;

public class OwnerPropertyDetailsSaveService extends JavaService{

	@Override
	public String executeService(String requestData) {
		ObjectMapper mapper = new ObjectMapper();
		MongoCollection collection = null;
		if(requestData != null) {
			try {
				collection  = MongoConnectionUtil.getCollection("PropertyMaster");
				JSONObject reqObject = new JSONObject(requestData);
				String input = reqObject.getString("REQUEST_DATA");
				OwnerObject obj = 	mapper.readValue(input, OwnerObject.class);
				System.out.println("Input object as json: "+obj.getDocument().toJson());
				collection.insertOne(obj.getDocument());
				System.out.println(obj.getDocument().get("_id")+" data inserted successfully...");
				
				//mapper.writeValueAsString(obj);
				//object to json..
				return "success";
			}catch (IOException e) {
				e.printStackTrace();
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		
		
		return null;
	}

}
