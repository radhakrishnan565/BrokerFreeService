package com.rs.server.service;



public abstract class JavaService {

	public abstract String executeService(String requestData);
}
