package com.rs.dao;

import org.bson.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties
public class PropertyDetails {

	String ownerId;
	String propertyId;
	Integer rentAmount;
	Integer depositAmount;
	Integer rentAmountRangeMinimum;
	Integer rentAmountRangeMaximum;
	String bhk;
	Integer squareFeet;
	ContactDetails propertyAddressContactDetails;
	PropertyOverview propertyOverview;
	
	public PropertyOverview getPropertyOverview() {
		return propertyOverview;
	}
	public void setPropertyOverview(PropertyOverview propertyOverview) {
		this.propertyOverview = propertyOverview;
	}
	public String getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
	public String getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(String propertyId) {
		this.propertyId = propertyId;
	}
	public ContactDetails getPropertyAddressContactDetails() {
		return propertyAddressContactDetails;
	}
	public void setPropertyAddressContactDetails(
			ContactDetails propertyAddressContactDetails) {
		this.propertyAddressContactDetails = propertyAddressContactDetails;
	}
	public Integer getRentAmount() {
		return rentAmount;
	}
	public void setRentAmount(Integer rentAmount) {
		this.rentAmount = rentAmount;
	}
	public Integer getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(Integer depositAmount) {
		this.depositAmount = depositAmount;
	}
	public Integer getRentAmountRangeMinimum() {
		return rentAmountRangeMinimum;
	}
	public void setRentAmountRangeMinimum(Integer rentAmountRangeMinimum) {
		this.rentAmountRangeMinimum = rentAmountRangeMinimum;
	}
	public Integer getRentAmountRangeMaximum() {
		return rentAmountRangeMaximum;
	}
	public void setRentAmountRangeMaximum(Integer rentAmountRangeMaximum) {
		this.rentAmountRangeMaximum = rentAmountRangeMaximum;
	}
	public String getBhk() {
		return bhk;
	}
	public void setBhk(String bhk) {
		this.bhk = bhk;
	}
	public Integer getSquareFeet() {
		return squareFeet;
	}
	public void setSquareFeet(Integer squareFeet) {
		this.squareFeet = squareFeet;
	}
	public Document getDocument(){
		Document document = new Document();
		document.append("ownerId", ownerId);
		document.append("propertyId", propertyId);
		document.append("rentAmount", rentAmount);
		document.append("depositAmount", depositAmount);
		document.append("rentAmountRangeMinimum", rentAmountRangeMinimum); 
		document.append("rentAmountRangeMaximum", rentAmountRangeMaximum); 
		document.append("bhk", bhk); 
		document.append("squareFeet", squareFeet);
		if(propertyAddressContactDetails != null) {
			document.append("propertyAddressContactDetails", propertyAddressContactDetails.getDocument());
		}
		if(propertyOverview != null) {
			document.append("propertyOverview", propertyOverview.getDocument());
		}
		return document;
	}

	
}
