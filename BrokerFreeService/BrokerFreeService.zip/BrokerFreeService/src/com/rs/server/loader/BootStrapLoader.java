package com.rs.server.loader;


public class BootStrapLoader {

	public void load(){
		System.out.println("Cool Bootstrap Successfully loaded....");
	}

}
