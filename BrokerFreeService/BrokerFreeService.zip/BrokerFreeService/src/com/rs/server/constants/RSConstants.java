package com.rs.server.constants;

public class RSConstants {
	//GateWay Channel constants
	public static final String SERVICE_ID = "SERVICE_ID";
	public static final String CHANNEL_ID = "CHANNEL_ID";
	public static final String SERVICE_VERSION = "SERVICE_VERSION";
	public static final String REQUEST_DATA = "REQUEST_DATA";
	public static final String RESPONSE_DATA = "RESPONSE_DATA";
	
	
	
	
}

