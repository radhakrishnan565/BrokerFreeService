package com.rs.test;

import java.io.IOException;

import org.bson.Document;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rs.dao.ContactDetails;
import com.rs.dao.OwnerObject;


public class JsonTest {

	public static void main(String[] args) {
		test();
	}
	public static void test(){
		ObjectMapper mapper = new ObjectMapper();
		try {
		OwnerObject obj = 	mapper.readValue("{ \"ownerId\":\"123\", \"name\":\"radhakrishnan\", \"display_description\":\"3 bhk flat for family\", \"contactDetails\":{ \"contactNo\":\"9042993310\", \"landline_no\":\"044-234324\", \"door_no\":\"157a\", \"city\":\"chennai\" }}", OwnerObject.class);
		System.out.println(obj.getName());
		ContactDetails conDetails = obj.getContactDetails();
		System.out.println(obj.getDocument().toJson());
		System.out.println(conDetails.getDocument().toJson());
		
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
